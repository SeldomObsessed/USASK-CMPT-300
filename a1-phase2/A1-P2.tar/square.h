/*
 * square.h
 * Logan Fossenier & William Morris
 * hzv143 & wjm625
 * 11343891 & 11278140
 * CMPT332 Fall 2025
 */


#ifndef SQUARE_H
#define SQUARE_H

extern int square_counter;
int square(int);
int is_valid(char*);  

#endif
